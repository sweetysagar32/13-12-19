export class Mode{
    name:String;
    value:String;
}