import { Mode } from './mode';

export const ITEMS: Mode[] = [
    {
        name:'Telephonic ',
        value:'item_1'
     },
     {
         name:' Personal (Face to Face) ',
         value:'item_2'
      },
      {
          name:'Webcam ( You being present in  front of webcam )',
          value:'item_3'
       },
       {
           name:'Personal ( Person is sitting in any one of Capgemini India locations and you talk over phone)',
           value:'item_4'
        }
        
         
];
 