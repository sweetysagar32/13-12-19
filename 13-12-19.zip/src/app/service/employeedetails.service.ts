import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeedetailsService {

  private baseUrl = 'http://localhost:8000';
  constructor(private http: HttpClient) { }

  getEmployeeDetails(id: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
 
  createEmployeeDetails(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/api/employees/create`, employee);
  }

  getemployeeDetailsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}` + `/api/employees`);
  }
  // createSkill(skill: Object): Observable<Object> {
  //   return this.http.post(`${this.baseUrl}` + `/api/skills`, skill);
  // }

}
