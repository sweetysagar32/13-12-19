import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { EmployeeDetails } from 'src/app/model/employeedetails';
import { EmployeedetailsService } from 'src/app/service/employeedetails.service';
import { Observable } from 'rxjs';
import { Skill } from 'src/app/model/skills';
import { Mode } from 'src/app/model/mode';
import {ITEMS} from 'src/app/model/modeInt';
import { Rating } from 'src/app/model/rating';
import { Rate } from 'src/app/model/techrating';

@Component({
  selector: 'app-l1form',
  templateUrl: './l1form.component.html',
  styleUrls: ['./l1form.component.css']
})

export class L1formComponent implements OnInit {
  employee: EmployeeDetails = new EmployeeDetails();
//  skill:Skill=new Skill();
//  skills:Skill[];
  employees: Observable<EmployeeDetails[]>;
  submitted = false;
  ngForm: FormGroup;
  invalidLogin: boolean=false;
  radioSel:any;
  radioSelected:String;
  radioSelectedString:String;
  itemsList: Mode[] = ITEMS;
  ratingList:Rating[] = Rate;
  
  radioSel1:any;
  radioSelected1:String;
  radioSelectedString1:String;


  textBoxDisabled = true;

  toggle(){
    this.textBoxDisabled = !this.textBoxDisabled;
  }

textBoxDisabled1 = true;

  toggle1(){
    this.textBoxDisabled1 = !this.textBoxDisabled1;
  }

// myClickFunction(event) {
//   alert("Registration Successful");
//   console.log(event);
// }


  list: any = [
    {id: 1, name: 'Java'},
    {id: 2, name: 'Angular 6'},
    {id: 3, name: 'Node Js'},
    {id: 4, name: 'Express Js'}
  ];
   current = 1;
  log = '';

  logDropdown(id: number): void {
    const NAME = this.list.find((item: any) => item.id === +id).name;
    this.log += `${NAME} \n`;
    console.log(this.log);
    this.employee.skill=this.log;
  //  this.skill.skillName=this.log;
  }

  
  // rating: any =[
  //   {rid: 1, rname: 'Not Applicable '},
  //   {rid: 2, rname: 'Inadequate / Not Relevant'},
  //   {rid: 3, rname: 'Adequate / Reasonably Relevant'},
  //   {rid: 4, rname: 'Good / Relevant'},
  //   {rid: 5, rname: 'Excellent / Very Relevant'},
  //   {rid: 6, rname: 'Outstanding / Ideal fitment'}
  // ];
  // present = 1;
  // res = '';
  
  // logDrop(rating: any): void {
  //   // const NAMES = this.rating.find((r: any) => r.rid === +rid).rname;
  //   // this.res += `${NAMES} \n`;
  //   console.log(rating.rname);
  //   this.employee.prating=this.rating.rname;
  //   // this.employee.crating=this.logs;
  //  //  this.skill.skillName=this.log;
  // }
  
  // select(value:string){
  //   this.employee.prating=value;
  //   console.log(value);
  // }
  //  rname: any;

  constructor(private formBuilder: FormBuilder, private router: Router, private employeeDetailsService: EmployeedetailsService) {
    this.itemsList = ITEMS;
    this.radioSelected = "item_3";
    this.getSelecteditem();

// this.ratingList=Rate;
// this.radioSelected1='3';
// this.getItem();
   }



  getSelecteditem(){
    this.radioSel = ITEMS.find(Mode => Mode.value === this.radioSelected);
     this.radioSelectedString = JSON.stringify(this.radioSel);
   // console.log(this.radioSel   )
   this.employee.mode=this.radioSelectedString;
  //  console.log(this.radioSelectedString)
  }

  onItemChange(item){
    this.getSelecteditem();
    // this.employee.mode=item;
    // console.log(item)

  }


  
  // getItem(){
  //   this.radioSel1 = Rate.find(Rating => Rating.value === this.radioSelected1);
  //    this.radioSelectedString1 = JSON.stringify(this.radioSel1);
  //  console.log(this.radioSel1  )
  //  this.employee.prating=this.radioSelectedString1;
  //   console.log(this.radioSelectedString1)
  // }

  // onItemChange1(item){
  //   this.getItem();
  // // this.employee.prating=item;
  //   //console.log(item)

  // }
  ngOnInit() {

      this.reloadData();

    this.ngForm = this.formBuilder.group({
      cname: ['', Validators.required],
      desc: ['', Validators.required],
      skill: ['', Validators.required],
      flexibility: ['', Validators.required],
      ename: ['', Validators.required],
      ecode: ['', Validators.required],
      doi:['', Validators.required],
      texp:['', Validators.required],
      rexp:['', Validators.required],
      list_name:['', Validators.required],
      location:['', Validators.required],
      hirecomment:['', Validators.required],
      rcomment:['', Validators.required],
      hcomment:['', Validators.required],
      iempcode:['', Validators.required],
      esign:['', Validators.required],
      psdes1:['', Validators.required],
  	 bjdes2:['', Validators.required],
	  kwdes:['', Validators.required],
  	ta1:['', Validators.required],
    ta2:['', Validators.required],
    ta3:['', Validators.required],
    ides:['', Validators.required],
    cides:['', Validators.required],
    sdes:['', Validators.required],
    fdes:['', Validators.required],
	
    });
  }

  reloadData() {
    this.employees = this.employeeDetailsService.getemployeeDetailsList();

  }
  // newEmployeeDetails(): void {
  //   this.submitted = false;
  //   this.employee = new EmployeeDetails();
  // }

  save() {
    this.employeeDetailsService.createEmployeeDetails(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new EmployeeDetails();
  }
  onSubmit() {
    this.submitted = true;
      this.save();
    // If validation failed, it should return
    // to Validate again
    if (this.ngForm.invalid) {
    return;
    }

     this.router.navigate(['/form']);

    }





}
