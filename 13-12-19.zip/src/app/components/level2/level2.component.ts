import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-level2',
  templateUrl: './level2.component.html',
  styleUrls: ['./level2.component.css']
})

export class Level2Component implements OnInit {

  Form: FormGroup;
  submitted:boolean= false;
  invalidLogin: boolean=false;
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  
  ngOnInit() {
    this.Form = this.formBuilder.group({
      userid: ['', Validators.required]
  
    });
  }
  onSubmit() {
    this.submitted = true;
    // If validation failed, it should return 
    // to Validate again
    if (this.Form.invalid) {
    return;
    }
  
    this.router.navigate(['userid']);
    }
   
    


}
